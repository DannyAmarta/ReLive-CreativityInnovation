---
name: Vibrant Utility
colors:
  surface: '#f3fceb'
  surface-dim: '#d4ddcc'
  surface-bright: '#f3fceb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eef7e5'
  surface-container: '#e8f1e0'
  surface-container-high: '#e2ebda'
  surface-container-highest: '#dce5d5'
  on-surface: '#161e13'
  on-surface-variant: '#3e4a39'
  inverse-surface: '#2b3327'
  inverse-on-surface: '#ebf4e3'
  outline: '#6d7b67'
  outline-variant: '#bccbb4'
  surface-tint: '#006e08'
  primary: '#006e08'
  on-primary: '#ffffff'
  primary-container: '#00aa13'
  on-primary-container: '#003402'
  inverse-primary: '#56e24b'
  secondary: '#5d5f5f'
  on-secondary: '#ffffff'
  secondary-container: '#dfe0e0'
  on-secondary-container: '#616363'
  tertiary: '#b80963'
  on-tertiary: '#ffffff'
  tertiary-container: '#fe4e97'
  on-tertiary-container: '#5b002d'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#76ff66'
  primary-fixed-dim: '#56e24b'
  on-primary-fixed: '#002201'
  on-primary-fixed-variant: '#005304'
  secondary-fixed: '#e2e2e2'
  secondary-fixed-dim: '#c6c6c7'
  on-secondary-fixed: '#1a1c1c'
  on-secondary-fixed-variant: '#454747'
  tertiary-fixed: '#ffd9e2'
  tertiary-fixed-dim: '#ffb1c8'
  on-tertiary-fixed: '#3e001d'
  on-tertiary-fixed-variant: '#8e004a'
  background: '#f3fceb'
  on-background: '#161e13'
  surface-variant: '#dce5d5'
typography:
  display-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Be Vietnam Pro
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 16px
  label-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 14px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 48px
  container-max: 1200px
---

## Brand & Style
The design system focuses on high-utility and energetic accessibility. It draws from a Modern Corporate aesthetic, stripping away unnecessary embellishments to prioritize clarity and speed. The personality is friendly but professional, evoking a sense of reliability and optimism. By utilizing a high-contrast primary color against a stark white canvas, the UI feels airy and expansive. Movement is suggested through purposeful whitespace and a clear visual hierarchy that guides the user through complex workflows with ease.

## Colors
The palette is dominated by pure White and a vibrant "Gojek Green." To maintain an airy feel, deep blacks are strictly avoided; instead, a soft Charcoal (#373A36) is used for primary text to reduce visual fatigue. 

- **Primary:** Used for call-to-actions, active states, and key brand moments.
- **Surface:** Backgrounds remain primarily white, with very light gray washes used to differentiate sections or cards.
- **Accents:** Semantic colors (red for errors, amber for warnings) should be desaturated to ensure they don't compete with the primary green.

## Typography
This design system utilizes **Be Vietnam Pro** for its contemporary, humanist qualities. The type scale is optimized for legibility at small sizes (essential for utility apps) while maintaining a bold, confident presence in headlines. 

For mobile devices, `display-lg` should scale down to 36px. All body text uses a standard weight of 400, while semantic labels and buttons use 500 or 600 weight to ensure they stand out against the light background.

## Layout & Spacing
The layout follows a 12-column fluid grid system. A base-8 spacing rhythm ensures consistency across all components and containers. 

- **Desktop:** 12 columns with 24px gutters. Content is typically centered in a maximum 1200px container.
- **Mobile:** 4 columns with 16px margins. 
- **Rhythm:** Use 8px, 16px, 24px, 32px, 48px, and 64px increments for all padding and margins to maintain vertical rhythm.

## Elevation & Depth
Depth is created through subtle ambient shadows rather than harsh lines. This reinforces the "airy" feel while providing clear signifiers of interactable layers.

- **Level 1 (Default):** Flat surfaces with a 1px border (#E8E8E8).
- **Level 2 (Cards/Dropdowns):** A soft shadow: `0px 4px 12px rgba(0, 0, 0, 0.05)`.
- **Level 3 (Modals/Floating Action Buttons):** A more pronounced shadow: `0px 8px 24px rgba(0, 0, 0, 0.10)`.

Background blurs are used sparingly for navigation bars to maintain context of the content behind them.

## Shapes
A "Rounded" shape language is applied across the system to appear welcoming and friendly. 
- **Small components (Buttons, Inputs):** 0.5rem (8px).
- **Medium components (Cards, Modals):** 1rem (16px).
- **Large containers:** 1.5rem (24px).
- **Search bars:** Often utilize full pill-shaping (circular ends) to denote a specialized high-priority action.

## Components
- **Buttons:** Primary buttons use a solid Gojek Green background with white text. Secondary buttons use a white background with a 1px border (#E8E8E8) and charcoal text.
- **Input Fields:** Use a 1px soft gray border. On focus, the border transitions to Gojek Green with a subtle 2px glow.
- **Chips:** Highly rounded (pill-shaped) with light gray backgrounds and charcoal text for filters; primary green backgrounds for active states.
- **Cards:** White background, 16px corner radius, and a Level 2 shadow. Padding inside cards should be generous (24px).
- **Lists:** Separated by thin 1px borders (#F0F0F0) with generous vertical padding (16px) to allow the "airy" aesthetic to persist even in data-heavy views.
- **Checkboxes/Radios:** Use Gojek Green for the checked state. Unchecked states use a soft gray border.